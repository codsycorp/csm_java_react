
// No AuthType needed for cookie-based auth

export interface UserInfoType {
	userId: string
	avatar: string
	username: string
	email: string
	phoneNumber: string
	full_name?: string
	description: string
	roles: string[]
	permissions: string[]
	menusPermissions: string[]
	app_id: string
	app_token: string
	dev?: boolean // Thêm dev flag từ backend
}

export interface AuthListProps {
	label: string
	name: string
	auth: string[]
}
