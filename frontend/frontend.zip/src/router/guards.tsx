import { usePreferences } from "#src/hooks";
import PageError from "#src/pages/error/page-error";
import { isString, toggleHtmlClass } from "#src/utils";
import { resolveDevFlag } from "#src/utils/dev-flag";
import { useAuthStore, useUserStore } from "#src/store";

import { useEffect } from "react";
import { ErrorBoundary } from "react-error-boundary";
import { useTranslation } from "react-i18next";
import { Outlet, useLocation, useMatches, Navigate } from "react-router";

/**
 * RouterGuards 组件用于路由守卫，主要处理路由守卫相关的逻辑。
 *
 * @returns 返回 JSX.Element，用于渲染 Outlet 组件。
 */
export function RouterGuards() {
	const matches = useMatches();
	const { t } = useTranslation();
	const location = useLocation();
	const { language, isDark } = usePreferences();
	// Đăng nhập dựa vào userId từ useUserStore
	const userId = useUserStore(state => state.userId);
	const userRoles = useUserStore(state => state.roles);
	const devFlag = useUserStore(state => state.dev);
	const isDev = resolveDevFlag(devFlag, userRoles);

	/* tailwind theme */
	useEffect(() => {
		if (isDark) {
			toggleHtmlClass("dark").add();
		}
		else {
			toggleHtmlClass("dark").remove();
		}
	}, [isDark]);

	/* Check authentication and roles - MUST be after all hooks */
	const currentRoute = matches[matches.length - 1];
	const routeHandle = currentRoute?.handle as any;
	
	// Check if route requires authentication (has roles requirement)
	if (routeHandle?.roles && Array.isArray(routeHandle.roles)) {
		// Check if user is logged in (has userId)
		   if (!userId) {
			   console.warn("🔒 Access denied: User not logged in, redirecting to /login?redirect=admin");
			   return <Navigate to="/login?redirect=admin" replace />;
		   }
		
		// Dev role has absolute access to ALL routes (highest privilege)
		const isDevUser = isDev || userRoles.includes("dev");
		if (isDevUser) {
			// console.log("✅ Dev user with absolute access, isDev:", isDev, "roles:", userRoles, "path:", location.pathname);
			return (
				<ErrorBoundary FallbackComponent={PageError}>
					<Outlet />
				</ErrorBoundary>
			);
		}
		
		// Admin system routes are only accessible to dev users.
		// IMPORTANT: Dynamic grid routes (/system/grid/...) are NOT admin routes and must remain accessible.
		const currentPath = location.pathname;
		const isAdminSystemRoute = currentPath.startsWith("/system") && !currentPath.startsWith("/system/grid");
		
		if (isAdminSystemRoute) {
			console.warn("🔒 Admin system route access denied: User role", userRoles, "is not 'dev'. Only dev users can access admin system routes.");
			return <Navigate to="/error/403" replace />;
		}
		
		// For non-system routes, check if user has required roles (admin or user)
		const hasRequiredRole = routeHandle.roles.some((requiredRole: string) => 
			userRoles.includes(requiredRole)
		);
		
		if (!hasRequiredRole) {
			console.warn("🔒 Access denied: User roles", userRoles, "don't match required roles", routeHandle.roles);
			return <Navigate to="/error/403" replace />;
		}
	}

	/* document title */
	/* ❌ DISABLED - Keep server-side rendered title for SEO (no duplicate title tags) */
	// useEffect(() => {
	// 	const currentRoute = matches[matches.length - 1];
	// 	const documentTitle = currentRoute.handle?.title as React.ReactElement | string;
	// 	const newTitle = isString(documentTitle) ? documentTitle : documentTitle?.props?.children;
	// 	document.title = t(newTitle) || document.title;
	// }, [language, location]);

	return (
		<ErrorBoundary FallbackComponent={PageError}>
			<Outlet />
		</ErrorBoundary>
	);
}
